$(document).ready(function(){
    var nombre= $("#nombre");
    var usuario=$("#usuario");
    var key=$("#key");
    var fecha=$("#fecha");
    var clave=$("#clave");
    var clave2=$("#clave2");
    
   nombre.blur(function(){
       var name= $(this).val();
       var error1="";
       if(name.trim().length==0|| name== null){
           console.log("error");
            error1= "<center>ingresa un nombre valido</center>"
           $("#enombre").html(error1);
           $("#enombre").show();
           $(this).css("border-bottom", "2px solid #9D1C1C");
       }else{
           error1= ""
            $("#enombre").hide();
           $(this).css("border", "solid transparent");
       }
       console.log(error1);
        //areglar esto
      
   });
    usuario.blur(function(){
        var error2="";
        var user=parseInt(usuario.val());
     
        
        if(isNaN(user) || user<0){
            error2="<center>El numero de usuario solo se permiten numeros</center>"
            $(this).css("border-bottom", "2px solid #9D1C1C");
            
        }else{
            $(this).css("border", "solid transparent");
            error2="";
            $("#eusuario").hide();
        }
        $("#eusuario").html(error2);
    });
    
    clave2.blur(function(){
        var error3="";
        var clav=$(this).val();
        if(clav != clave.val()){
            $(this).css("border-bottom", "2px solid #9D1C1C");
            clave.css("border-bottom", "2px solid #9D1C1C");
            error3="<center>las contraseñas no coinciden</center>"
        }else{
            $(this).css("border", "solid transparent");
            clave.css("border", "solid transparent");
            error3="";
            $("#eclave2").hide();
        }
        $("#eclave2").html(error3);
    });
    
    $("#chechombre").on("click",function(){
       $("#checmujer").attr('checked', false);
    });
    
    $("#checmujer").on("click",function(){
        $("#chechombre").attr('checked', false);
    });
    
});