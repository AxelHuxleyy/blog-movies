
var TuFecha = new Date();
var numero=30;
  //dias a sumar
  
  console.log(TuFecha);
  //nueva fecha sumada
  TuFecha.setDate(TuFecha.getDate() + 30);


var dateControl = document.querySelector('input[type="date"]');
dateControl.value = TuFecha.getFullYear() + '-' +
    (TuFecha.getMonth() + 1) + '-' + TuFecha.getDate();;

